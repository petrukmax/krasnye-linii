# -*- coding: utf-8 -*-
"""International press dossier for the «СМИ» section."""

SMI_BLOCKS = [
    {
        "id": "s2",
        "num": "СМИ · Блок II · 2014–2023",
        "title": "Дипломатический срыв в зеркале прессы",
        "lead": "Как Foreign Affairs, Die Zeit, TASS, Ukrainska Pravda и Berliner Zeitung разобрали лекцию Миршаймера, признание Меркель о Минске и стамбульский срыв.",
    },
    {
        "id": "s3",
        "num": "СМИ · Блок III · 2024",
        "title": "Вашингтон, ВПК и доллар: реакция американских медиа",
        "lead": "Как интервью Сакса и разбор Гринвальда разошлись по The Hill, подкастам и дискуссии о неоконсерваторах и оборонных контрактах.",
    },
    {
        "id": "s4",
        "num": "СМИ · Блок IV · 2022–2024",
        "title": "Азия и БРИКС глазами азиатской и мировой прессы",
        "lead": "China Daily, NZZ, Indian Express, Hindustan Times, SCMP, Reuters и POLITICO о позиции 85% мира, речи Джайшанкара и Мюнхене Ван И.",
    },
]

SMI_ITEMS = [
    {
        "file": "smi-01-mearsheimer-fa.html",
        "img": "img/02.jpg",
        "gallery": ["img/02.jpg", "img/rot04.jpg", "img/rot03.jpg"],
        "block": 0,
        "n": "01",
        "date": "август 2014 — сентябрь 2015",
        "place": "Foreign Affairs · University of Chicago News",
        "kind": "Статья и академический разбор в СМИ",
        "title": "Foreign Affairs: «Why the Ukraine Crisis Is the West’s Fault»",
        "source": "https://www.foreignaffairs.com/articles/russia-fsu/2014-08-18/why-ukraine-crisis-wests-fault",
        "source_name": "Foreign Affairs",
        "desc": "Ещё до лекции 2015 года главный журнал американского истеблишмента напечатал тезис Миршаймера: корневая причина кризиса — расширение НАТО, а не «реваншизм» Москвы. Западная пресса годами спорила с этой статьёй; после 2022-го её цитируют и сторонники, и критики как документ, предсказавший войну.",
        "cap": "Аудитория и архив: как академический текст стал предметом газетной войны.",
        "links": [
            ("Foreign Affairs, 18.08.2014", "https://www.foreignaffairs.com/articles/russia-fsu/2014-08-18/why-ukraine-crisis-wests-fault"),
            ("University of Chicago News", "https://news.uchicago.edu/why-ukraine-crisis-wests-fault"),
            ("Лекция 2015 (видео)", "https://www.youtube.com/watch?v=a4hDilZbR_M"),
        ],
        "brief": [
            "Foreign Affairs (сентябрь/октябрь 2014) публикует статью Миршаймера с подзаголовком «The Liberal Delusions That Provoked Putin».",
            "Журнал Совета по международным отношениям — не маргинальная площадка, а ядро американского внешнеполитического истеблишмента.",
            "Тезис, подхваченный прессой: три пружины кризиса — НАТО, ЕС и поддержка прозападных сил в Украине с 2004 года.",
            "Критики в Atlantic, Washington Post и later Foreign Affairs называли текст «оправданием агрессии»; реалисты — единственным объяснением, совместимым с балансом сил.",
            "Лекция 2015 года на YouTube сделала статью массовым документом: пресса спорит уже не с журналом, а с видео, набравшим миллионы просмотров.",
        ],
        "full": """
<h2>Где это напечатали</h2>
<p>18 августа 2014 года <em>Foreign Affairs</em> выкладывает статью Джона Дж. Миршаймера «Why the Ukraine Crisis Is the West’s Fault». Бумажный номер — сентябрь/октябрь 2014, том 93, выпуск 5, с. 77–89. Издание принадлежит Совету по международным отношениям. То есть спор о «вине Запада» начался не в Telegram и не на RT, а в журнале, который читают в Госдепартаменте.</p>
<p>Университет Чикаго в тот же месяц ставит материал в свою ленту новостей как op-ed профессора политологии. Через год устная версия — лекция Uncommon Core — уходит на YouTube и становится одним из самых цитируемых западных разборов кризиса.</p>

<h2>Что именно подхватила пресса</h2>
<p>Первый абзац статьи ломает «общепринятую мудрость»: винить только российскую агрессию и имперский зуд Путина — ошибка. «Соединённые Штаты и их европейские союзники несут большую часть ответственности». Корень — enlargement НАТО как центральный элемент стратегии вывести Украину из российской орбиты; параллельно — расширение ЕС и поддержка «продемократического» движения начиная с Оранжевой революции 2004 года.</p>
<p>Формула, которую потом повторят и азиатские колонки, и Сакс, и Махбубани: великая держава не терпит враждебный военный блок у своих границ. Миршаймер прямо пишет, что свержение Януковича Путин «справедливо назвал переворотом» — формулировка, из‑за которой либеральные СМИ заклеймили текст как «близорукий реализм».</p>

<h2>Как спорили издания</h2>
<p>Линия критики (типичная для атлантистской прессы 2014–2022): реализм обеляет нарушение Будапештского меморандума и аннексию Крыма; «сферы влияния» — язык XIX века. Линия защиты: Грузия-2008 уже была предупреждением, Бухарест-2008 — красной тряпкой, а обещание членства Украине без готовности воевать за неё — безответственная провокация.</p>
<p>После февраля 2022 статья переживает второе рождение. Её перепечатывают, разбирают на подкастах, ставят в оппозицию к формуле Байдена «unprovoked war». Для архива важно: это не «российская пропаганда в западной обёртке», а внутренний спор американской школы реализма с либеральным интервенционизмом, задокументированный за семь лет до СВО.</p>
""",
        "quotes": [
            (
                "The taproot of the trouble is NATO enlargement, the central element of a larger strategy to move Ukraine out of Russia’s orbit and integrate it into the West.",
                "John J. Mearsheimer, Foreign Affairs, август 2014",
            ),
            (
                "But this account is wrong: the United States and its European allies share most of the responsibility for the crisis.",
                "Там же",
            ),
        ],
    },
    {
        "file": "smi-02-merkel-pressa.html",
        "img": "img/03.jpg",
        "gallery": ["img/03.jpg", "img/rot02.jpg", "img/rot01.jpg"],
        "block": 0,
        "n": "02",
        "date": "7–14 декабря 2022",
        "place": "Die Zeit · TASS · Marianne · Courrier International",
        "kind": "Волна публикаций после интервью",
        "title": "Как мировые СМИ прочитали признание Меркель о Минске",
        "source": "https://www.zeit.de/2022/51/angela-merkel-international-politik-taiwan-ukraine-russland",
        "source_name": "Die Zeit",
        "desc": "После интервью экс-канцлера Die Zeit европейская, российская и французская пресса разошлись в оценках одной фразы: Минск «дал Украине время». TASS пишет о «заявке на трибунал», Marianne — о камне в политическое болото, Courrier International собирает «вид из Москвы».",
        "cap": "Газетный стол и зимний Берлин: как одна цитата разошлась по столицам.",
        "links": [
            ("Die Zeit, оригинал интервью", "https://www.zeit.de/2022/51/angela-merkel-international-politik-taiwan-ukraine-russland"),
            ("TASS, 8.12.2022", "https://tass.com/politics/1547779"),
            ("Marianne, 14.12.2022", "https://www.marianne.net/agora/les-signatures-de-marianne/les-accords-de-minsk-devaient-donner-du-temps-a-lukraine-angela-merkel-jette-un-pave-dans-la-mare"),
            ("Courrier International, 12.12.2022", "https://www.courrierinternational.com/article/vu-de-moscou-apres-l-interview-de-merkel-la-russie-denonce-la-tromperie-des-europeens-lors-des-accords-de-minsk"),
        ],
        "brief": [
            "7 декабря 2022 Die Zeit публикует большое интервью Ангелы Меркель: «Минское соглашение 2014 года было попыткой дать Украине время».",
            "8 декабря TASS передаёт комментарий Марии Захаровой: это «заявка на трибунал», признание в махинации 2014–2015 годов.",
            "9 декабря пресса цитирует Путина в Бишкеке: возникает «вопрос доверия», «может, надо было начинать раньше».",
            "12 декабря Courrier International делает подборку «Vu de Moscou»: российские сайты читают фразу как «мы обманули Путина».",
            "14 декабря Marianne (Франция) удивляется молчанию западных столиц и называет интервью «камнем в болото».",
        ],
        "full": """
<h2>Первоисточник</h2>
<p>Немецкий еженедельник <em>Die Zeit</em>, номер 51/2022. Меркель отвечает на вопрос, не были ли «спокойные годы» годами упущений. Она защищает свою линию: альтернативы 2008 и 2014 нужно называть вслух. Бухарестское обещание НАТО Украине и Грузии она считает ошибкой. И сразу — формула, обошедшая агентства:</p>
<p><em>«Das Minsker Abkommen 2014 war der Versuch, der Ukraine Zeit zu geben. Sie hat diese Zeit auch genutzt, um stärker zu werden, wie man heute sieht.»</em></p>
<p>Редакция Die Zeit в сноске поясняет: цель соглашений — выиграть время перемирием. Меркель добавляет Дебальцево: в начале 2015-го Россию, по её оценке, было не остановить, и НАТО не смогло бы помочь так, как помогает в 2022-м.</p>

<h2>TASS и линия Москвы</h2>
<p>Уже 8 декабря TASS выпускает материал «Merkel’s confession about Minsk Agreements a solid bid for a tribunal». Захарова: всё, что делалось в 2014–2015, имело одну цель — отвлечь мир, купить время, накачать Киев оружием и довести дело до большого конфликта. Это не «неудавшийся мир», а, в этой рамке, заранее заложенный обман.</p>
<p>Новая газета. Европа и российские агентства на следующий день разносят ответ Путина: европейские гаранты «обманывали нас», время Минска ушло на «накачку» Украины. Фраза «раньше нужно было начинать» становится заголовком.</p>

<h2>Париж и «вид из Москвы»</h2>
<p><em>Marianne</em> 14 декабря удивляется, что западный мейнстрим почти промолчал, тогда как смысл сказанного очевиден: Минск был не дорогой к миру, а паузой для перевооружения. <em>Courrier International</em> 12 декабря собирает российские заголовки в рубрике «Vu de Moscou»: от «да, мы обманули Путина» до юридического языка МИДа. Для архива ценна именно эта развилка рецепции: один и тот же абзац Die Zeit в Берлине читают как спасение Украины от разгрома, в Москве — как исчерпание дипломатии.</p>
""",
        "quotes": [
            (
                "The 2014 Minsk Agreement was an attempt to buy time for Ukraine. Ukraine used this time to become stronger, as you can see today.",
                "Цитата Меркель в передаче TASS, 8.12.2022",
            ),
            (
                "This, however, is a solid bid for a tribunal. […] everything that was done in 2014 and 2015 had only one goal: to divert the global community’s attention […], to buy some time, to pump the Kiev regime with weapons.",
                "Мария Захарова, TASS, 8.12.2022",
            ),
        ],
    },
    {
        "file": "smi-03-stambul-pressa.html",
        "img": "img/04.jpg",
        "gallery": ["img/04.jpg", "img/rot06.jpg", "img/rot05.jpg"],
        "block": 0,
        "n": "03",
        "date": "24–28 ноября 2023",
        "place": "1+1 · Ukrainska Pravda · Berliner Zeitung · Antiwar.com",
        "kind": "Телеинтервью и международный разбор",
        "title": "Стамбул-2022: как пресса разобрала откровения Арахамии",
        "source": "https://www.pravda.com.ua/eng/news/2023/11/24/7430282/",
        "source_name": "Ukrainska Pravda",
        "desc": "Глава украинской делегации на «1+1» подтвердил: Россия была готова остановить войну в обмен на нейтралитет и отказ от НАТО, а Борис Джонсон по возвращении из Стамбула сказал «просто воевать». Ukrainska Pravda, Berliner Zeitung, Meduza и Antiwar.com разложили интервью на цитаты — с разными выводами о том, кто сорвал мир.",
        "cap": "Пустой зал переговоров у пролива: медиареконструкция Стамбула весны 2022-го.",
        "links": [
            ("Интервью, YouTube / 1+1", "https://www.youtube.com/watch?v=TGXa89zjpDI"),
            ("Ukrainska Pravda, 24.11.2023", "https://www.pravda.com.ua/eng/news/2023/11/24/7430282/"),
            ("Berliner Zeitung, 25.11.2023", "https://www.berliner-zeitung.de/article/boris-johnson-fraktionsvorsitzender-der-selenskyj-partei-ukraine-krieg-haette-2022-beendet-sein-koennen-2162278"),
            ("Antiwar.com, 25.11.2023", "https://news.antiwar.com/2023/11/25/ukrainian-official-confirms-russia-was-ready-to-end-war-in-march-2022-if-kyiv-agreed-to-neutrality/"),
            ("Meduza, 28.11.2023", "https://meduza.io/en/feature/2023/11/28/we-had-to-buy-time"),
        ],
        "brief": [
            "24 ноября 2023 Давид Арахамия на «1+1» (Наталия Мосейчук) говорит: ключевым требованием Москвы был нейтралитет «как у Финляндии» и отказ от НАТО; остальное — «косметика».",
            "Ukrainska Pravda в тот же день выкладывает английскую версию: Киев не верил гарантиям; Джонсон по приезде в Киев сказал не подписывать и воевать.",
            "Berliner Zeitung выносит в заголовок Джонсона: война могла закончиться через несколько недель.",
            "Antiwar.com формулирует жёстче: украинский официальный подтвердил готовность России закончить войну в марте 2022-го ценой нейтралитета.",
            "Meduza собирает реакции обеих сторон и напоминает: сам Арахамия отрицает, что Запад «принял решение за Киев» — партнёры «советовали».",
        ],
        "full": """
<h2>Что сказал Арахамия — по расшифровкам прессы</h2>
<p>Ukrainska Pravda 24 ноября 2023 фиксирует слова главы фракции «Слуга народа», руководившего делегацией в Беларуси и Турции. Русская сторона «почти до последнего надеялась», что удастся продавить соглашение о нейтралитете. «They were willing to end the war if we took on neutrality, like Finland once did, and gave assurances that we wouldn’t join NATO. That was essentially the main point. Everything else was cosmetic.»</p>
<p>Дальше — два ограничителя, которые западные и российские СМИ акцентируют по-разному. Первый: у делегации не было права подписывать, это могли сделать только президенты. Второй: «когда мы вернулись из Стамбула, приехал Борис Джонсон и сказал, что мы вообще ничего не подпишем и давайте просто воевать».</p>

<h2>Берлин, Вашингтон, Киев — три рамки</h2>
<p><em>Berliner Zeitung</em> ставит тезис в заголовок: война могла быть закончена через несколько недель; британский премьер призвал продолжать. Американский Antiwar.com (Кайл Анзалоне) называет это подтверждением прежних расследований о почти готовом договоре. Meduza озаглавливает разбор «We had to buy time» и показывает, как российская пропаганда ликует, а киевские спикеры уточняют: доверия к Москве не было, конституция требует курса на НАТО, Запад не приказывал, а советовал не лезть в «эфемерные гарантии».</p>
<p>Для досье важен не суд над Джонсоном, а документированная развилка марта 2022-го, признанная участником переговоров на украинском телеканале. Нейтралитет как цена остановки огня — больше не «версия Москвы», а цитата главы делегации Киева, разошедшаяся по европейской и американской прессе.</p>
""",
        "quotes": [
            (
                "They were ready to end the war if we, like Finland once did, would accept neutrality and pledge not to join NATO. In fact, that was the main point.",
                "Д. Арахамия, 1+1, в передаче Ukrainska Pravda / Berliner Zeitung",
            ),
            (
                "Moreover, when we returned from Istanbul, Boris Johnson came to Kyiv and said that we would not sign anything with them at all, and let’s just fight.",
                "Там же",
            ),
        ],
    },
    {
        "file": "smi-04-saks-pressa.html",
        "img": "img/06.jpg",
        "gallery": ["img/06.jpg", "img/rot10.jpg", "img/rot05.jpg"],
        "block": 1,
        "n": "04",
        "date": "28–29 мая 2024",
        "place": "The Tucker Carlson Show · The Hill / Rising",
        "kind": "Интервью и телеразбор",
        "title": "Джеффри Сакс у Карлсона: как The Hill и сетевые СМИ разобрали неоконов",
        "source": "https://www.youtube.com/watch?v=JS-3QssVPeg",
        "source_name": "YouTube / Tucker Carlson",
        "desc": "Двухчасовое интервью экономиста и экс-советника ООН Такеру Карлсону (28 мая 2024) The Hill вынес в утренний эфир Rising уже на следующий день. Сакс связывает расширение НАТО, санкции, удар по европейской промышленности и ускорение БРИКС в одну макроэкономическую цепь — и американские студии спорят, «умнейшая оценка войны» это или изоляционизм.",
        "cap": "Пустая студия после эфира: американский разговор о цене санкций.",
        "links": [
            ("Полное интервью, 28.05.2024", "https://www.youtube.com/watch?v=JS-3QssVPeg"),
            ("Apple Podcasts, The Tucker Carlson Show", "https://podcasts.apple.com/us/podcast/jeffrey-sachs-the-untold-history-of-the-cold-war/id1719657632?i=1000657058513"),
            ("The Hill / Rising, 29.05.2024", "https://www.youtube.com/watch?v=dyJqKVBx9l4"),
        ],
        "brief": [
            "28 мая 2024 The Tucker Carlson Show выкладывает 2 часа 24 минуты с Джеффри Саксом; Карлсон в анонсе называет это «probably the smartest and most accurate assessment of the Ukraine war».",
            "Оглавление, которое цитирует пресса: зачем Америка толкала Украину в НАТО; кто такие неоконы; почему «regime change never works»; кто взорвал «Северные потоки».",
            "29 мая The Hill в программе Rising (Бриана Джой Грей, Робби Соэйв) делает короткий разбор: Сакс бьёт по политике администрации Байдена.",
            "Сакс описывает 30 лет ошибок: от расширения НАТО до санкций, которые, по его словам, деиндустриализировали Европу и подтолкнули торговлю к БРИКС.",
            "Сетевые СМИ делятся на два лагеря: «наконец экономист сказал вслух» и «профессор подыгрывает Москве». Сам текст интервью — в первоисточнике.",
        ],
        "full": """
<h2>Как это упаковали медиа</h2>
<p>Карлсон выкладывает выпуск 28 мая 2024 с таймкодами, которые сразу растащили клипмейкеры и The Hill: 20:17 — зачем США толкали Украину в НАТО; 58:34 — что такое неокон; 1:25:28 — смена режимов не работает; 1:36:27 — Nord Stream; 2:01:45 — происхождение COVID. Именно нарезка, а не академическая монография, сделала Сакса героем недельной медиаповестки.</p>
<p>The Hill / Rising на следующий день берёт куски про Украину и «пушечное мясо». Ведущие фиксируют: это не маргинальный блогер, а бывший советник генсека ООН, директор Центра устойчивого развития в Columbia University, автор «The End of Poverty».</p>

<h2>О чём спорит пресса</h2>
<p>Сакс выстраивает цепь: обещания 1990-х не расширять НАТО; Бухарест-2008; отказ обсуждать нейтралитет Украины в декабре 2021-го; санкции, ударившие по немецкой химии и машиностроению; укрепление расчётов в юанях и рупиях. Для одних колонок это «макроэкономический реализм». Для других — опасное смешение корреляции и вины, игнорирующее агентность Москвы.</p>
<p>В архиве этот сюжет стоит в блоке III, потому что пресса здесь обсуждает не линию фронта, а внутреннюю машину Вашингтона: неоконов, оборонный бюджет и цену санкций для союзников. Полный разговор — по ссылке на первоисточник; ниже — только то, что издания вынесли на обложку.</p>
""",
        "quotes": [
            (
                "Jeffrey Sachs with probably the smartest and most accurate assessment of the Ukraine war, and American foreign policy more broadly, ever caught on tape.",
                "Анонс Tucker Carlson, 28.05.2024",
            ),
        ],
    },
    {
        "file": "smi-05-grinvold-pressa.html",
        "img": "img/07.jpg",
        "gallery": ["img/07.jpg", "img/rot10.jpg", "img/rot02.jpg"],
        "block": 1,
        "n": "05",
        "date": "2024",
        "place": "System Update · совместный разбор с Такером Карлсоном",
        "kind": "Подкаст / видеоразбор в медиасреде",
        "title": "Гринвальд и Карлсон: ВПК, цензура и запрос на вечную войну",
        "source": "https://www.youtube.com/watch?v=KPpSKjIWBLU",
        "source_name": "YouTube",
        "desc": "Лауреат Пулитцера разбирает, как военно-промышленный комплекс, спецслужбы и крупные платформы США создают спрос на затяжные конфликты. Пресса и клипы 2024 года выносят из выпуска схему: оборонные контракты → информационная мобилизация → табу на дипломатию.",
        "cap": "Камеры выключены, контракты остаются: визуальный ряд к разговору о ВПК.",
        "links": [
            ("Выпуск System Update / Карлсон", "https://www.youtube.com/watch?v=KPpSKjIWBLU"),
        ],
        "brief": [
            "Гленн Гринвальд — Pulitzer Prize, сооснователь The Intercept, ведущий System Update — в 2024-м садится с Карлсоном разобрать «глубинное государство» не как конспирологию, а как сращивание интересов.",
            "Схема, которую цитируют нарезки: ВПК нуждается в долгих войнах; медиаплатформы — в моральной мобилизации; спецслужбы — в расширении мандата.",
            "Украина в этом разборе — не единственный театр, а актуальный пример: многомиллиардные пакеты помощи совпадают с рекордной прибылью подрядчиков.",
            "Отдельная линия — цензура: от давления на платформы после 2022-го до ярлыка «пропаганда», наклеиваемого на разговор о нейтралитете и Минске.",
            "Критики называют союз Гринвальда и Карлсона «странным альянсом левого антиимпериализма и правого изоляционизма»; для архива важен сам факт, что эта рамка вышла в массовый видеоформат.",
        ],
        "full": """
<h2>Почему это попало в раздел СМИ</h2>
<p>System Update — не классическая газета, но в 2024 году именно подкасты стали тем каналом, через который англоязычная аудитория получает длинный разбор ВПК. Гринвальд, в отличие от анонимных телеграм-каналов, — фигура с биографией в мейнстриме: разоблачения АНБ, The Intercept, Пулитцер. Когда он садится с Карлсоном, американские студии вынуждены либо спорить, либо замалчивать.</p>

<h2>О чём говорят, если отбросить ругань</h2>
<p>Связка простая и потому удобная для прессы. Подрядчики (Lockheed, Raytheon, General Dynamics) зарабатывают на номенклатуре, которая списывается в чужой войне. Конгрессмены округов, где стоят заводы, голосуют за пакеты. Редакции получают доступ и героев. Платформы, согласовав «борьбу с дезинформацией», сужают коридор до формулы «непровоцированная агрессия / больше оружия». Дипломатия в этой конструкции выглядит как пораженчество — и вытесняется.</p>
<p>Гринвальд настаивает: это не требует тайного комитета. Достаточно совпадения стимулов. Для блока III архива выпуск — медиадокумент о внутренних мотивах Вашингтона, парный к макроэкономике Сакса.</p>
""",
        "quotes": [
            (
                "Соединённые интересы ВПК, спецслужб и ведущих медиаплатформ формируют информационную цензуру и создают запрос на постоянное затягивание внешних конфликтов ради многомиллиардных оборонных контрактов.",
                "Тезис выпуска, конспект для архива",
            ),
        ],
    },
    {
        "file": "smi-06-mahbubani-pressa.html",
        "img": "img/08.jpg",
        "gallery": ["img/08.jpg", "img/rot07.jpg", "img/rot03.jpg"],
        "block": 2,
        "n": "06",
        "date": "2023–2025",
        "place": "China Daily · Pearls and Irritations · NZZ · Foreign Policy",
        "kind": "Колонки и интервью",
        "title": "«85% мира»: как пресса разнесла тезис Махбубани",
        "source": "https://global.chinadaily.com.cn/a/202305/19/WS646719fba310b6054fad3fb0.html",
        "source_name": "China Daily",
        "desc": "Сингапурский дипломат повторяет цифру, которую подхватили China Daily, австралийский John Menadue, швейцарская NZZ и Foreign Policy: санкции против РФ не поддержали страны, где живёт около 85% человечества. Для азиатской прессы это не оправдание вторжения, а приговор западной монополии на моральный рассказ о войне.",
        "cap": "Ночной город Азии за стеклом пустого зала: визуальный ряд к «концу западной эпохи».",
        "links": [
            ("China Daily, 19.05.2023", "https://global.chinadaily.com.cn/a/202305/19/WS646719fba310b6054fad3fb0.html"),
            ("John Menadue / Pearls and Irritations, 28.02.2023", "https://johnmenadue.com/time-for-the-west-to-rethink-goal-of-total-defeat-for-russia-in-ukraine/"),
            ("NZZ English, 28.04.2025", "https://www.nzz.ch/english/top-singaporean-diplomat-the-west-is-floundering-ld.1881227"),
            ("Foreign Policy, 26.03.2025", "https://foreignpolicy.com/2025/03/26/europe-us-alliances-russia-ukraine-nato/"),
            ("Выступление, YouTube", "https://www.youtube.com/watch?v=1VOyni-m4FQ"),
        ],
        "brief": [
            "China Daily (19.05.2023) выносит в заголовок: «Mahbubani: 85% of the world's population didn't sanction Russia».",
            "В лекции 2023 года он говорит, что американцы этого не знают и при этом клеймят Китай, хотя Пекин не поставляет Москве оружие и деньги — в его формулировке.",
            "На Pearls and Irritations (Австралия) колонка «Time for the West to rethink goal of total defeat»: Глобальный Юг не покупает чёрно-белую картинку.",
            "NZZ: «If you’re European, you must ask yourself, did we succeed in isolating Russia, or did Russia succeed in isolating Europe?»",
            "Foreign Policy (2025): конфискация замороженных активов в глазах большинства мира будет выглядеть кражей — отсюда же вопрос, почему 85% не присоединились к санкциям.",
        ],
        "full": """
<h2>Цифра, ставшая мемом прессы</h2>
<p>«85%» — не данные Росстата, а формула сингапурского дипломата Кишора Махбубани, которую азиатские и европейские издания повторяют как укор евроцентризму. China Daily фиксирует её после лекции 2023 Anthony C. Janetos Memorial: Запад не изолировал Россию, Россия (вместе с незападным большинством) изолировала Запад.</p>
<p>В колонке для John Menadue (февраль 2023) Махбубани уточняет: большинство Глобального Юга голосовало в ГА ООН против вторжения — и почти никто не ввёл санкции. Причина, пишет он, не любовь к Кремлю, а отказ от сказки «Запад добродетелен, Россия абсолютно зла». За пятьдесят лет в геополитике он «не встречал ни одного сюжета, где право целиком на одной стороне».</p>

<h2>NZZ и Foreign Policy</h2>
<p>Швейцарская NZZ в английском интервью 2025 года заостряет: война могла быть предотвращена, если бы Европа серьёзно отнеслась к озабоченностям Москвы; Бухарест-2008 — красная тряпка. Вторжение незаконно. Но санкции поддержали ~15% населения Земли. «Did we isolate Russia, or did Russia isolate Europe?»</p>
<p>Foreign Policy даёт тот же авторский голос уже в 2025-м, в тексте о стратегическом «reboot» Европы: изъятие российских активов без международно-правовой санкции большинство мира сочтёт кражей. Вопрос «почему 85% не с нами?» предлагается задать себе, а не Пекину. Для блока IV это главный медиадокумент: конфликт глазами Азии — это конфликт про конец двухсотлетней привычки Запада говорить от имени человечества.</p>
""",
        "quotes": [
            (
                "Mahbubani revealed that 85 percent of the world's population has not participated in the Western sanctions imposed on Russia, which is a fact that many Americans are ignorant of.",
                "China Daily, 19.05.2023",
            ),
            (
                "If you’re European, you must ask yourself, did we succeed in isolating Russia, or did Russia succeed in isolating Europe?",
                "Kishore Mahbubani, NZZ, 2025",
            ),
        ],
    },
    {
        "file": "smi-07-djaishankar-pressa.html",
        "img": "img/09.jpg",
        "gallery": ["img/09.jpg", "img/rot08.jpg", "img/rot07.jpg"],
        "block": 2,
        "n": "07",
        "date": "3–5 июня 2022",
        "place": "The Indian Express · Hindustan Times · Mint",
        "kind": "Речь на форуме и индийская пресса",
        "title": "Джайшанкар на GLOBSEC: индийские газеты против евроцентризма",
        "source": "https://indianexpress.com/article/india/europe-has-to-grow-out-of-mindset-that-its-problems-are-worlds-problems-jaishankar-7951895/",
        "source_name": "The Indian Express",
        "desc": "The Indian Express, Hindustan Times и Mint вынесли в заголовки фразу министра иностранных дел Индии на GLOBSEC в Братиславе: Европа должна перерасти мысль, будто её проблемы — проблемы всего мира. Это манифест независимой политики Дели — и ключ к тому, почему Нью-Дели не присоединился к санкциям.",
        "cap": "Пустой министерский коридор: визуальный ряд к речи, которую подхватила вся индийская пресса.",
        "links": [
            ("The Indian Express, 4.06.2022", "https://indianexpress.com/article/india/europe-has-to-grow-out-of-mindset-that-its-problems-are-worlds-problems-jaishankar-7951895/"),
            ("Hindustan Times, 3.06.2022", "https://www.hindustantimes.com/india-news/no-india-not-sitting-on-fence-jaishankar-says-europe-has-to-change-mindset-101654245499431.html"),
            ("Mint, 4.06.2022", "https://www.livemint.com/news/india/lets-be-even-handed-jaishankar-slams-europe-s-criticism-of-india-s-oil-trade-with-russia-key-points-11654332010037.html"),
            ("Речь / дискуссия, YouTube", "https://www.youtube.com/watch?v=UThAT9D1q8M"),
        ],
        "brief": [
            "3 июня 2022 на GLOBSEC в Братиславе С. Джайшанкар произносит фразу, ставшую заголовком всех крупных индийских газет.",
            "The Indian Express: «Europe has to grow out of the mindset that its problems are the world’s problems but the world’s problems are not Europe’s problems».",
            "Hindustan Times выносит другую формулу: «I am not sitting on the fence […] I am sitting on my ground».",
            "Mint разбирает нефтяной спор: Европа сама покупает российские энергоносители, но стыдит Индию за ту же закупку.",
            "Связка Китай–Украина, которую ему подсовывают в зале, он отводит: конфликт с КНР старше украинского и не требует «сделки» по лояльности Западу.",
        ],
        "full": """
<h2>Что напечатали в Дели на следующее утро</h2>
<p>The Indian Express 4 июня 2022 делает из братиславской реплики политический манифест. Министра спросили, как Индия после «молчания» по Украине будет просить помощи против Китая. Ответ, который цитируют все: Европа должна вырасти из привычки считать свои кризисы мировыми, а чужие — чужими. «China and India happened way before anything happened in Ukraine. […] I don’t see this frankly as a very clever argument, a very self-serving one.»</p>
<p>Hindustan Times в тот же день: Индия — пятая-шестая экономика и пятая часть человечества, она «имеет право на свою сторону». «My choices will not be cynical and transactional. They will be a balance of my values and my interests.» Mint собирает «key points» по нефти: новый пакет санкций ЕС сконструирован с заботой о европейском потребителе; «if you can be considerate to yourself, surely you can be considerate to others».</p>

<h2>Почему это медиасобытие, а не только речь</h2>
<p>GLOBSEC — атлантистский форум. Произнести там отказ от евроцентризма и защитить закупки российской нефти — значит дать индийским газетам цитату, которую больше не нужно объяснять через «давление Москвы». Пресса Дели читает это как суверенитет, европейская — как уклонение. Для блока IV архива важен именно газетный слой: Independent Asia говорит своим голосом, и этот голос напечатан не в пропагандистском листке, а в Indian Express и Hindustan Times.</p>
""",
        "quotes": [
            (
                "Europe has to grow out of the mindset that Europe’s problems are the world’s problems but the world’s problems are not Europe’s problems.",
                "S. Jaishankar, GLOBSEC 2022, цитата The Indian Express",
            ),
            (
                "I am not sitting on the fence just because I don’t agree with you. It means I am sitting on my ground.",
                "Hindustan Times, 3.06.2022",
            ),
        ],
    },
    {
        "file": "smi-08-van-i-pressa.html",
        "img": "img/10.jpg",
        "gallery": ["img/10.jpg", "img/rot09.jpg", "img/rot01.jpg"],
        "block": 2,
        "n": "08",
        "date": "17–18 февраля 2024",
        "place": "Xinhua / People’s Daily · SCMP · Reuters · POLITICO",
        "kind": "Речь и международная хроника",
        "title": "Ван И в Мюнхене-2024: Китай в западной и китайской прессе",
        "source": "https://www.scmp.com/news/china/diplomacy/article/3252295/munich-security-conference-chinas-wang-yi-defends-ties-russia-warns-west-taiwan-red-line",
        "source_name": "South China Morning Post",
        "desc": "На 60-й Мюнхенской конференции глава МИД КНР назвал Китай «силой стабильности». Xinhua подчёркивает Global Security Initiative и неделимость безопасности, SCMP — защиту связей с Москвой и «красную линию» по Тайваню, Reuters — разговор с Кулебой о мире, POLITICO — отказ вырезать Китай из мировой экономики.",
        "cap": "Пустой зал с красными колоннами: атмосфера, в которой пресса разбирала китайский Мюнхен.",
        "links": [
            ("People’s Daily / Xinhua, 18.02.2024", "https://en.people.cn/n3/2024/0218/c90000-20133870.html"),
            ("South China Morning Post, 17.02.2024", "https://www.scmp.com/news/china/diplomacy/article/3252295/munich-security-conference-chinas-wang-yi-defends-ties-russia-warns-west-taiwan-red-line"),
            ("Reuters, 17.02.2024", "https://www.reuters.com/world/ukrainian-foreign-minister-discusses-peace-prospects-with-chinese-counterpart-2024-02-17/"),
            ("POLITICO Europe, 17.02.2024", "https://www.politico.eu/article/china-munich-wang-yi-global-economy-foreign-minister/"),
            ("Выступление, YouTube", "https://www.youtube.com/watch?v=71QdeiPMcL4"),
        ],
        "brief": [
            "17 февраля 2024 Ван И на MSC произносит речь «Firmly acting as a force for stability in a turbulent world» — так её титулует Xinhua / People’s Daily.",
            "SCMP: министр жёстко защищает отношения с Россией и предупреждает Запад не переходить «красную линию» по Тайваню.",
            "Reuters: на полях Кулеба обсуждает с ним «справедливый и прочный мир»; Китай обещает не подливать масла и не продавать летальное оружие в зону конфликта.",
            "POLITICO: «the global economy is a big ocean that cannot be cut into isolated lakes» — выпад против европейского de-risking.",
            "Общий знаменатель четырёх редакций: Пекин предлагает не блоковую, а «неделимую» безопасность и институты БРИКС/ШОС как альтернативу.",
        ],
        "full": """
<h2>Четыре редакции — четыре рамки одного дня</h2>
<p><strong>Xinhua / People’s Daily.</strong> Официальная стенография: мир в турбулентности, односторонность и блоковая политика бьют по международной системе, Китай сохраняет преемственность и будет «силой стабильности». Отдельно — Global Security Initiative, невмешательство, отказ навязывать свою модель. Это язык, которым Пекин хочет быть записан в историю конференции.</p>
<p><strong>South China Morning Post.</strong> Гонконгская газета читает ту же речь как силовую защиту связи с Москвой и предупреждение по Тайваню: тайваньский вопрос «нельзя сравнивать с Красным морем», это внутреннее дело, «Тайвань никогда не был страной». Для западной аудитории MSC это звучит как отказ поставить Россию на место.</p>
<p><strong>Reuters.</strong> Агентство выносит не зал, а кулуары: встреча с Дмитрием Кулебой. Китай «will continue to push for a political resolution through dialogue», не будет «add fuel to the fire» и торговать летальным оружием. Ван И: переговоры нужно возобновить как можно скорее, «as long as there is still a glimmer of hope for peace, we will not give up».</p>
<p><strong>POLITICO Europe.</strong> Экономический кадр: Китай нельзя вырезать из мировой экономики. «Those who attempt to shut China out in the name of de-risking will make a historical mistake.» Океан нельзя нарезать на изолированные озёра — прямой ответ Брюсселю.</p>

<h2>Зачем это в архиве</h2>
<p>Мюнхен-2024 рифмуется с Мюнхеном-2007: снова зал, снова спор о праве силы и блоках, но голос уже не Москвы, а Пекина. Западная пресса фиксирует отказ Китая присоединиться к санкционной коалиции; китайская — концепцию неделимой безопасности. Вместе это и есть «конфликт глазами Азии», записанный четырьмя редакциями в одни сутки.</p>
""",
        "quotes": [
            (
                "No matter how the world changes, China is a responsible major country that will keep its major principles and policies consistent and stable … In a turbulent world China will be a force for stability.",
                "Ван И, MSC 2024, цитата SCMP",
            ),
            (
                "Those who attempt to shut China out in the name of de-risking will make a historical mistake.",
                "Ван И, цитата POLITICO Europe, 17.02.2024",
            ),
        ],
    },
]
