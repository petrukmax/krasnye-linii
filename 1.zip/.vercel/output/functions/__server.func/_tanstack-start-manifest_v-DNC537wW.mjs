//#region node_modules/.nitro/vite/services/ssr/assets/_tanstack-start-manifest_v-DNC537wW.js
var tsrStartManifest = () => ({ routes: {
	__root__: {
		filePath: "/workspace/src/routes/__root.tsx",
		children: ["/"],
		preloads: ["/assets/index-1LXF0ilS.js"],
		scripts: [{ attrs: {
			type: "module",
			async: !0,
			src: "/assets/index-1LXF0ilS.js"
		} }]
	},
	"/": {
		filePath: "/workspace/src/routes/index.tsx",
		children: void 0,
		preloads: ["/assets/routes-DBr5iMy3.js"]
	}
} });
//#endregion
export { tsrStartManifest };
