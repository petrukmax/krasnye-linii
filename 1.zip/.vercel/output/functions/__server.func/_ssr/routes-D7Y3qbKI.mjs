import { v as require_jsx_runtime } from "../_libs/@tanstack/react-router+[...].mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/routes-D7Y3qbKI.js
var import_jsx_runtime = require_jsx_runtime();
function Home() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("main", {
		className: "archive-shell",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
			className: "sr-only",
			children: "Красные линии — архив первоисточников 2007–2024"
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("iframe", {
			src: "/archive/index.html",
			title: "Красные линии — архив первоисточников"
		})]
	});
}
//#endregion
export { Home as component };
