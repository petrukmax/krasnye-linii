import { createFileRoute } from "@tanstack/react-router";

export const Route = createFileRoute("/")({ component: Home });

function Home() {
  return (
    <main className="archive-shell">
      <h1 className="sr-only">Красные линии — архив первоисточников 2007–2024</h1>
      <iframe
        src="/archive/index.html"
        title="Красные линии — архив первоисточников"
      />
    </main>
  );
}
